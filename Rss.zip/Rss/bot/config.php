<?php
	$api = 'https://api.telegram.org/bot';
	$bot = '305662874:AAE27Nyi12h7y1zCyLxjO2oD-JEz57YpErc'; //TOKEN BOT

	define('SUDOS', array(
		'0' => '263799625', //SUDO ID
		'1' => '96438491'
	));

	define('API_BOT', $api . $bot);
	define('CONTEXTO', stream_context_create(array('http' => array('header'=>'Connection: close\r\n'))));
	define('RAIZ', system('pwd') . '/');
	define('VERSAO', '4.0.0 (SGF)');