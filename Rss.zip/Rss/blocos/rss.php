<?php
	if ($idioma == 'PT') {
		if (strtolower($texto[0]) == '/rss') {
			$mensagem = 'CRIAR AJUDA DO RSS';

			$teclado = [
										'inline_keyboard'	=>	[
																						[
																							['text' => 'ESPORTES', 'callback_data' => 'ESPORTES']
																						],
																						[
																							['text' => '⚽️ Campeonatos', 'callback_data' => '/campeonatos'],
																							['text' => '⚽️ Times', 'callback_data' => '/times'],
																							['text' => '🏆 Outros', 'callback_data' => '/esportes']
																						],
																						[
																							['text' => 'TECNOLOGIA', 'callback_data' => 'TECNOLOGIA']
																						],
																						[
																							['text' => '🐸 Pplware', 'callback_data' => '/pplware'],
																							['text' => '💻 CanalTech', 'callback_data' => '/canaltech'],
																							['text' => '📱 AndroidPit', 'callback_data' => '/androidpit']
																						],
																						[
																							['text' => 'NOTÍCIAS', 'callback_data' => 'NOTÍCIAS']
																						],
																						[
																							['text' => '🌏 Folha SP', 'callback_data' => '/folha'],
																							['text' => '🌎 G1', 'callback_data' => '/g1'],
																							['text' => '🌏 Terra', 'callback_data' => '/terra']
																						],
																						[
																							['text' => '🔙', 'callback_data' => '/start']
																						]
																					]
									];

			$replyMarkup = json_encode($teclado);
		} else if (strtolower($texto[0]) == '/campeonatos') {
			$mensagem = 'Escolha o seu campeonato preferido:';

			$teclado = [
										'inline_keyboard'	=>	[
																						[
																							['text' => '⚽️ Futebol em geral', 'callback_data' => '/futebolgeral']
																						],
																						[
																							['text' => 'Brasileirão Série A', 'callback_data' => '/brasileiroa']
																						],
																						[
																							['text' => 'Brasileirão Série B', 'callback_data' => '/brasileirob']
																						],
																						[
																							['text' => 'Campeonato Paulista', 'callback_data' => '/paulista']
																						],
																						[
																							['text' => 'Campeonato Carioca', 'callback_data' => '/carioca']
																						],
																						[
																							['text' => 'Campeonato Mineiro', 'callback_data' => '/mineiro']
																						],
																						[
																							['text' => 'Campeonato Gaúcho', 'callback_data' => '/gaucho']
																						],
																						[
																							['text' => 'Copa do Brasil', 'callback_data' => '/copabrasil']
																						],
																						[
																							['text' => 'Copa Libertadores', 'callback_data' => '/libertadores']
																						],
																						[
																							['text' => 'Copa Sul-Americana', 'callback_data' => '/sulamericana']
																						],
																						[
																							['text' => 'Champions League', 'callback_data' => '/champions']
																						],
																						[
																							['text' => 'Campeonato Inglês', 'callback_data' => '/ingles']
																						],
																						[
																							['text' => 'Campeonato Espanhol', 'callback_data' => '/espanha']
																						],
																						[
																							['text' => 'Campeonato Italiano', 'callback_data' => '/italia']
																						],
																						[
																							['text' => 'Campeonato Alemão', 'callback_data' => '/alemao']
																						],
																						[
																							['text' => 'Campeonato Português', 'callback_data' => '/portugal']
																						],
																						[
																							['text' => '🔙', 'callback_data' => '/rss']
																						]
																					]
									];

			$replyMarkup = json_encode($teclado);
		} else if (strtolower($texto[0]) == '/times') {
			$mensagem = 'Escolha o seu time preferido:';

			$teclado = [
									'inline_keyboard'	=>	[
																					[
																						['text' => 'ABC', 'callback_data' => '/abc']
																					],
																					[
																						['text' => 'América-RN', 'callback_data' => '/americarn']
																					],
																					[
																						['text' => 'Atlético Mineiro', 'callback_data' => '/atleticomg']
																					],
																					[
																						['text' => 'Atlético Paranaense', 'callback_data' => '/atleticopr']
																					],
																					[
																						['text' => 'Bahia', 'callback_data' => '/bahia']
																					],
																					[
																						['text' => 'Botafogo', 'callback_data' => '/botafogo']
																					],
																					[
																						['text' => 'Ceará', 'callback_data' => '/ceara']
																					],
																					[
																						['text' => 'Corinthians', 'callback_data' => '/corinthians']
																					],
																					[
																						['text' => 'Coritiba', 'callback_data' => '/coritiba']
																					],
																					[
																						['text' => 'Criciúma', 'callback_data' => '/criciuma']
																					],
																					[
																						['text' => 'Cruzeiro', 'callback_data' => '/cruzeiro']
																					],
																					[
																						['text' => 'Flamengo', 'callback_data' => '/flamengo']
																					],
																					[
																						['text' => 'Fluminense', 'callback_data' => '/fluminense']
																					],
																					[
																						['text' => 'Fortaleza', 'callback_data' => '/fortaleza']
																					],
																					[
																						['text' => 'Goiás', 'callback_data' => '/goias']
																					],
																					[
																						['text' => 'Grêmio', 'callback_data' => '/gremio']
																					],
																					[
																						['text' => 'Internacional', 'callback_data' => '/internacional']
																					],
																					[
																						['text' => 'Náutico', 'callback_data' => '/nautico']
																					],
																					[
																						['text' => 'Palmeiras', 'callback_data' => '/palmeiras']
																					],
																					[
																						['text' => 'Ponte Preta', 'callback_data' => '/pontepreta']
																					],
																					[
																						['text' => 'Portuguesa', 'callback_data' => '/portuguesa']
																					],
																					[
																						['text' => 'Santa Cruz', 'callback_data' => '/santacruz']
																					],
																					[
																						['text' => 'Santos', 'callback_data' => '/santos']
																					],
																					[
																						['text' => 'São Paulo', 'callback_data' => '/saopaulo']
																					],
																					[
																						['text' => 'Sport', 'callback_data' => '/sport']
																					],
																					[
																						['text' => 'Vasco da Gama', 'callback_data' => '/vascodagama']
																					],
																					[
																						['text' => 'Vitória', 'callback_data' => '/vitoria']
																					],
																					[
																						['text' => 'Arsenal', 'callback_data' => '/arsenal']
																					],
																					[
																						['text' => 'Barcelona', 'callback_data' => '/barcelona']
																					],
																					[
																						['text' => 'Bayern de Munique', 'callback_data' => '/bayerndemunique']
																					],
																					[
																						['text' => 'Borussia Dortmund', 'callback_data' => '/borussiadortmund']
																					],
																					[
																						['text' => 'Chelsea', 'callback_data' => '/chelsea']
																					],
																					[
																						['text' => 'Inter de Milão', 'callback_data' => '/interdemilao']
																					],
																					[
																						['text' => 'Juventus', 'callback_data' => '/juventus']
																					],
																					[
																						['text' => 'Liverpool', 'callback_data' => '/liverpool']
																					],
																					[
																						['text' => 'Manchester City', 'callback_data' => '/manchestercity']
																					],
																					[
																						['text' => 'Manchester United', 'callback_data' => '/manchesterunited']
																					],
																					[
																						['text' => 'Milan', 'callback_data' => '/milan']
																					],
																					[
																						['text' => 'Paris Saint-Germain', 'callback_data' => '/parissaintgermain']
																					],
																					[
																						['text' => 'Real Madrid', 'callback_data' => '/realmadrid']
																					],
																					[
																						['text' => '🔙', 'callback_data' => '/rss']
																					]
																				]
								];

			$replyMarkup = json_encode($teclado);
		} else if (strtolower($texto[0]) == '/esportes') {
			$mensagem = 'Escolha o seu esporte preferido:';

			$teclado = [
									'inline_keyboard'	=>	[
																					[
																						['text' => '🏆 Esportes em geral', 'callback_data' => '/esportesgeral']
																					],
																					[
																						['text' => '🏋 MMA', 'callback_data' => '/mma']
																					],
																					[
																						['text' => '🎾 Tênis', 'callback_data' => '/tenis']
																					],
																					[
																						['text' => '🏐 Vôlei', 'callback_data' => '/volei']
																					],
																					[
																						['text' => '🏀 Basquete', 'callback_data' => '/basquete']
																					],
																					[
																						['text' => '🔙', 'callback_data' => '/rss']
																					]
																				]
								];

			$replyMarkup = json_encode($teclado);
		}

		sendMessage($mensagens['message']['chat']['id'], $mensagem, $mensagens['message']['message_id'], $replyMarkup, true, $mensagens['edit_message']);
	}
