<?php
	$redis = new Redis();
	$redis->connect('127.0.0.1', '6379');
	$redis->select(4);
	$bkp = json_decode(file_get_contents('/home/mkriel/backup.json'), true);

	foreach ($bkp as $key => $value) {
		$redis->hset('documentos:store', $key, $value['id']);
	}
