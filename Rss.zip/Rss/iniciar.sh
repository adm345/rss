#!/bin/bash
while true; do php bot/bot.php; done;
